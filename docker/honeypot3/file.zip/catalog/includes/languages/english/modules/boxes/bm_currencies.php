<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_CURRENCIES_TITLE', 'Currencies');
  define('MODULE_BOXES_CURRENCIES_DESCRIPTION', 'Show available currencies');
  define('MODULE_BOXES_CURRENCIES_BOX_TITLE', 'Currencies');
?>

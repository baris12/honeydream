<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ACTION_RECORDER_TELL_A_FRIEND_TITLE', 'Tell A Friend');
  define('MODULE_ACTION_RECORDER_TELL_A_FRIEND_DESCRIPTION', 'Record usage of the Tell A Friend feature.');
?>

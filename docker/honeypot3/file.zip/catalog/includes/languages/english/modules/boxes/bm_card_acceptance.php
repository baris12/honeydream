<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_CARD_ACCEPTANCE_TITLE', 'Card Acceptance');
  define('MODULE_BOXES_CARD_ACCEPTANCE_DESCRIPTION', 'Show payment card acceptance logos');

  define('MODULE_BOXES_CARD_ACCEPTANCE_SHOWN_CARDS', 'Shown Cards');
  define('MODULE_BOXES_CARD_ACCEPTANCE_NEW_CARDS', 'New Cards');
  define('MODULE_BOXES_CARD_ACCEPTANCE_DRAG_HERE', 'Drag Here');

  define('MODULE_BOXES_CARD_ACCEPTANCE_BOX_TITLE', 'We Accept');
?>

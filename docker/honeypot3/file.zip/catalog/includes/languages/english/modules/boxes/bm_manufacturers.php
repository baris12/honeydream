<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_MANUFACTURERS_TITLE', 'Manufacturers');
  define('MODULE_BOXES_MANUFACTURERS_DESCRIPTION', 'Show a list of manufacturers');
  define('MODULE_BOXES_MANUFACTURERS_BOX_TITLE', 'Manufacturers');
?>
